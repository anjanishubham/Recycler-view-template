package com.example.kotlintemplate.Adapter

import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import com.example.kotlintemplate.R
import com.example.kotlintemplate.model.Student
import kotlinx.android.synthetic.main.student_detail.view.*

class MyAdapter(private val interaction: Interaction? = null) :
        RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    val DIFF_CALLBACK = object : DiffUtil.ItemCallback<Student>() {

        override fun areItemsTheSame(oldItem: Student, newItem: Student): Boolean {
            return oldItem.studentRoll==newItem.studentRoll
        }

        override fun areContentsTheSame(oldItem: Student, newItem: Student): Boolean {
           return oldItem==newItem
        }

    }
    private val differ = AsyncListDiffer(this, DIFF_CALLBACK)


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

        return MyVIewHolder(
                LayoutInflater.from(parent.context).inflate(
                        R.layout.student_detail,
                        parent,
                        false
                ),
                interaction
        )
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is MyVIewHolder -> {
                holder.bind(differ.currentList.get(position))
            }
        }
    }

    override fun getItemCount(): Int {
        return differ.currentList.size
    }

    fun submitList(list: List<Student>) {
        differ.submitList(list)
    }

    class MyVIewHolder
    constructor(itemView: View, private val interaction: Interaction?) : RecyclerView.ViewHolder(itemView) {

        fun bind(item: Student): Unit = with(itemView) {
            itemView.setOnClickListener {
                interaction?.onItemSelected(adapterPosition, item)
            }
            itemView.student_name.text=item.studentName
            itemView.student_roll.text=item.studentRoll.toString();
        }
    }

    interface Interaction {
        fun onItemSelected(position: Int, item: Student)
    }
}

