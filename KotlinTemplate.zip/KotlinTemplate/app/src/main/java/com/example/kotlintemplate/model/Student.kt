package com.example.kotlintemplate.model

data class Student(public val studentName:String,
                   public val studentRoll:Int,
                   public val studentAddress:String,
                   public val studentPhoneNumber:String){
    companion object{
        fun initStudentList():ArrayList<Student>{
            var studentList = ArrayList<Student>()
            for(i in 1..20){
                val student=Student("rahul",10+i,"Delhi","7897798870")
                studentList.add(student)
            }
            return studentList
        }
    }

}