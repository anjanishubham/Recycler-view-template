package com.example.kotlintemplate;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.widget.LinearLayout;

import com.example.kotlintemplate.Adapter.MyAdapter;
import com.example.kotlintemplate.model.Student;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private ArrayList<Student> studentArrayList=new ArrayList();
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView=findViewById(R.id.rv);
       // recyclerview.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(new LinearLayoutManager(this,RecyclerView.VERTICAL,false));
        MyAdapter myAdapter=new MyAdapter();
        studentArrayList=Student.Companion.initStudentList();
        for(Student student:studentArrayList)
        Log.d(TAG, "onCreate: "+student.toString());
        recyclerView.setAdapter(myAdapter);
        myAdapter.submitList(studentArrayList);
    }
}
